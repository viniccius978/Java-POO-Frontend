package br.com.PdvFrontEnd.model;

public enum TipoPreco {
}
